/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import { Rule } from '@angular-devkit/schematics';
/** Entry point for the migration schematics with target of Angular CDK 21.0.0 */
export declare function updateToV21(): Rule;
/** Entry point for the migration schematics with target of Angular CDK 22.0.0 */
export declare function updateToV22(): Rule;
