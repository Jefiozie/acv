import { Version } from '@angular/core';

const VERSION = new Version('21.2.12');

export { VERSION };
//# sourceMappingURL=cdk.mjs.map
