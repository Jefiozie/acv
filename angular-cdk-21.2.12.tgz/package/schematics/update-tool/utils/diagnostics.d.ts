/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import * as ts from 'typescript';
import { FileSystem } from '../file-system';
/** Formats the specified diagnostics with respect to the given file system. */
export declare function formatDiagnostics(diagnostics: ts.Diagnostic[], fileSystem: FileSystem): string;
